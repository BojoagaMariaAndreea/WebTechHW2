function addTokens(input, tokens){
    
    if(typeof(input)!="string")
    {
        throw new Error('Invalid input');
    }
    if(input.length<6)
    {
        throw new Error('Input should have at least 6 characters');
    }
    let ok=0;
    for(var i=0; i<tokens.length; i++) {
        if((tokens[i].hasOwnProperty("tokenName") && typeof (tokens[i])["tokenName"] === 'string')) {
            ok++;
        }
    }
    if(ok!=tokens.length)
    {
        throw new Error("Invalid array format");
    }
    if(!(input.includes("...")))
    {
        return input;
    }else
    {
        for(i=0;i<tokens.length;i++)
        {
            input = input.replace("...", "${"+tokens[i]["tokenName"]+"}");
            //console.log(input);
        }
        return input;
    }

    
}

const app = {
    addTokens: addTokens
}

module.exports = app;